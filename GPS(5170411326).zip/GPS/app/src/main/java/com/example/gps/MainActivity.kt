package com.example.gps

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*


class MainActivity : AppCompatActivity() {

    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var locationRequest: LocationRequest
    lateinit var  locationCallback: LocationCallback

    val REQUEST_CODE = 1000;

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)


        when(requestCode)
        {
            REQUEST_CODE->{
                if(grantResults.size > 0 )
                {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
                        Toast.makeText(this@MainActivity, "Permition granted",Toast.LENGTH_SHORT)
                            .show()
                    else
                        Toast.makeText(this@MainActivity, "Permition denied", Toast.LENGTH_SHORT)
                            .show()
                }
            }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION))
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_CODE)
        else
        {
            buildLocationRequest()
            buildLocationCallBack()

            fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

            btn_start_update.setOnClickListener(View.OnClickListener {
                if (ActivityCompat.checkSelfPermission(this@MainActivity,android.Manifest.permission
                        .ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&

                        ActivityCompat.checkSelfPermission(this@MainActivity, android.Manifest.permission
                            .ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(
                        android.Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_CODE)
                    return@OnClickListener
                }

                fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback,
                    Looper.myLooper())

                btn_start_update.isEnabled= !btn_start_update.isEnabled

            })

            btn_stop_update.setOnClickListener( View.OnClickListener {

                if (ActivityCompat.checkSelfPermission(this@MainActivity, android.Manifest.permission
                        .ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this@MainActivity, android.Manifest.permission
                        .ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(this@MainActivity,
                        arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_CODE)
                    return@OnClickListener
                }
                            fusedLocationProviderClient.removeLocationUpdates(locationCallback)


            })
        }
    }


    private fun buildLocationCallBack () {
        locationCallback = object :LocationCallback() {
            override fun onLocationResult(p0: LocationResult?) {

                super.onLocationResult(p0)
                var location = p0!!.locations.get(p0!!.locations.size-1)

                coordinate()
            }
        }
    }

    private fun buildLocationRequest() {
        locationRequest = LocationRequest()
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        locationRequest.fastestInterval = 3000
        locationRequest.smallestDisplacement = 10f
    }

    private fun getAdress(lat: Double, lang : Double){
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses : List<Address> = geocoder.getFromLocation(lat, lang, 1)
        val city: String?
        val pCode: String?
        val country: String?

        val obj = addresses[0]
        city = obj.locality
        pCode = obj.postalCode
        country = obj.countryName

        val lines = System.lineSeparator()
        val text1 = "$lat / $lang"
        val text =  "Kota = $city $lines" +
                    "Kode Pos = $pCode $lines" +
                    "Negara = $country"

        text_tampil.text = text
        text_location.text = text1
    }
    private fun coordinate(){
        var lat = 0.0
        var longl = 0.0
        rgp_container.setOnCheckedChangeListener { group, checkedId ->
            when(checkedId){
                R.id.rbn_madrid->{
                    lat = 40.4165657
                    longl = -3.6967432
                    getAdress(lat,longl)
                }
                R.id.rbn_jakarta->{
                    lat = -6.2118628
                    longl = 106.8463483
                    getAdress(lat,longl)
                }
                R.id.rbn_paris->{
                    lat = 61.501535
                    longl = 105.412688
                    getAdress(lat,longl)
                }
            }
        }
    }
}

